package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class MyController {
	
	@Value("${prop.value}")
	private int fetchedvalue1;
	@Value("${prop.value.new}")
	private int fetchedvalue2;
//	@Value("${prop.value.new.one}")
//	private int fetchedvalue21;
//	
	
	@GetMapping("/prop")
//	@HystrixCommand(fallbackMethod = "fallbackMethod")
	public String val() {
//		throw new RuntimeException("Not Available");
		return "old :"+fetchedvalue1+" new :"+fetchedvalue2;
	}
	
	
	
	public String fallbackMethod() {
		return "old : 0 new : 0";
	}
	
	@GetMapping("Div")
	public int va() {
		return 2;
	}
	

}
